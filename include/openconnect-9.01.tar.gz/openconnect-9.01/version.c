const char openconnect_version_str[] = "v9.01";
